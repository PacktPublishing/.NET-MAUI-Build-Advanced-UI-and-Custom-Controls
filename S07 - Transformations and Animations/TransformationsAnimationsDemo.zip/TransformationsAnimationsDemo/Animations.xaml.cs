using System.Diagnostics;

namespace TransformationsAnimationsDemo;

public partial class Animations : ContentPage
{
    public Animations()
    {
        InitializeComponent();
    }

    private async void AnimationButton_Clicked(object sender, EventArgs e)
    {
        #region Single Animations
        //await image.TranslateTo(100, 0, 1000);
        //await image.ScaleTo(2, 1000);
        //await image.RotateTo(90, 1000);
        //await image.RotateXTo(45, 1000);
        //await image.FadeTo(0, 1000);

        //image.Rotation = 180;

        //await image.RotateTo(360, 3000);
        //await image.RelRotateTo(360, 3000);
        #endregion

        #region Compound Animations

        //////Translation
        //await image.TranslateTo(100, 0, 1000);
        //await image.TranslateTo(100, 100, 50);
        //await image.TranslateTo(0, 100, 2000);
        //await image.TranslateTo(0, 0, 500);



        //////Scaling
        //await image.ScaleTo(2, 1000);
        //await image.ScaleTo(0, 1000);
        //await image.ScaleTo(6, 1000);
        //await image.ScaleTo(0, 1000);
        //await image.ScaleTo(10, 1000);
        //await image.ScaleTo(0, 1000);



        ////Rotation
        //await image.RotateTo(90, 1000);
        //await image.RotateTo(0, 1000);
        //await image.RotateTo(180, 1000);
        //await image.RotateTo(0, 1000);
        //await image.RotateTo(270, 1000);
        //await image.RotateTo(0, 1000);
        //await image.RotateTo(360, 1000);
        //await image.RotateTo(0, 1000);



        ////Skew
        //await image.RotateXTo(45, 1000);
        //await image.RotateYTo(45, 1000);
        //await image.RotateXTo(0, 1000);
        //await image.RotateYTo(0, 1000);



        ////Fade
        //image.Opacity = 0;
        //await image.FadeTo(1, 2500);
        //await image.FadeTo(0, 2500);

        #endregion

        #region Composite Animations

        //image.TranslateTo(250, 250, 3000);
        //await image.RotateTo(360, 3000);

        #endregion

        #region Animations Concurrently

        //await Task.WhenAll(
        //        image.TranslateTo(100, 0, 3000),
        //        image.RotateTo(360, 5000)
        //    );
        //var cancelled =  await image.FadeTo(0, 1000);

        //if(cancelled)
        //{
        //    image.Rotation = 0;
        //}

        #endregion

        #region Easing Functions

        //await image.TranslateTo(100,100,2000, Easing.SinIn);
        //await image.TranslateTo(0, 0, 2000, Easing.SinOut);

        //await image.TranslateTo(100, 100, 2000, Easing.CubicIn);
        //await image.TranslateTo(0, 0, 2000, Easing.CubicOut);

        //await image.TranslateTo(100, 100, 2000, Easing.BounceIn);
        //await image.TranslateTo(0, 0, 2000, Easing.BounceOut);

        //await image.TranslateTo(100, 100, 2000, Easing.SpringIn);
        //await image.TranslateTo(0, 0, 2000, Easing.SpringOut);


        #endregion

        #region Custom Easing Functions

        //await image.TranslateTo(100, 0, 5000, (Easing)Linear);

        //Func<double, double> linear = t => t;
        //await image.TranslateTo(100, 0, 5000, linear);

        //var easing = new Easing(t => t);

        //var easing = new Easing(t =>
        //    { 
        //        var result = (int)(5 * t) / 5.0;
        //        Debug.WriteLine(result);
        //        return result;
        //    });

        //await image.TranslateTo(100, 0, 5000, easing);

        #endregion

        #region Custom Animations

        //var animation =
        //    new Animation(v => Debug.WriteLine(v), 0, 1);

        //animation.Commit(this, "CustomAnimation", 16, 1000);


        //var animation =
        //   new Animation(v => image.RotationY = v, 0, 360);

        //animation.Commit(this, 
        //    "CustomAnimation", 
        //    16, 
        //    1000, 
        //    Easing.Linear, 
        //    (fv, c) => image.Scale += 0.1, 
        //    () => true);

        #endregion

        #region Child Animations

        var parentAnimation = new Animation();
        var rotateXAnimation = new Animation(v => image.RotationX = v, 0, 360);
        var scaleUpAnimation = new Animation(v => image.Scale = v, 1, 2);
        var opacityAnimation = new Animation(v => image.Opacity = v, 0, 1);
        var scaleDownAnimation = new Animation(v => image.Scale = v, 2, 1);

        var fraction = .1666;

        parentAnimation.Add(0, (fraction * 6), rotateXAnimation);
        parentAnimation.Add(0, (fraction * 3), scaleUpAnimation);
        parentAnimation.Add(0, (fraction * 2), opacityAnimation);
        parentAnimation.Add(0, (fraction * 4), scaleDownAnimation);

        parentAnimation.Commit(this, "childAnimations", 16, 6000);




        #endregion

    }

    private double Linear(double t)
    {
        Debug.WriteLine($"Linear: {t}");
        return t;
    }


    private void CancelButton_Clicked(object sender, EventArgs e)
    {
        //image.CancelAnimations();
        Microsoft.Maui.Controls.ViewExtensions.CancelAnimations(image);
    }
}