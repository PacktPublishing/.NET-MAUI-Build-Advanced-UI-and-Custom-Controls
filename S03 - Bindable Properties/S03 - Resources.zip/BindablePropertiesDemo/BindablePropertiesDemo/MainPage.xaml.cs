﻿namespace BindablePropertiesDemo
{
    public partial class MainPage : ContentPage
    {
        MainPageViewModel _viewModel;
        public MainPage(MainPageViewModel viewModel)
        {
            InitializeComponent();
            _viewModel = viewModel;
            BindingContext = _viewModel;


            //BindingTest.SetValue(Label.TextProperty, "Testing SetValue method");    
            
            //BindingTest.Text = "Testing Text property";




        }      
    }

}
