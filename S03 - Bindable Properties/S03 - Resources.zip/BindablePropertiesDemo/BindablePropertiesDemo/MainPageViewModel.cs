﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BindablePropertiesDemo
{
    public partial class MainPageViewModel : ObservableObject
    {
        [ObservableProperty]
        string title = "0% To Complete";

        [ObservableProperty]
        double progress;

        [ObservableProperty]
        string subTitle = "Current Download";

        partial void OnProgressChanged(double value)
        {
            Title = $"{value * 100}% To Complete";
        }


        public MainPageViewModel()
        {
            Progress = (1 - 0.5);
        }

        [RelayCommand]
        public async Task Download()
        {
            Progress = 0.0;
            for(int i = 0; i <=100;i++)
            {
                await Task.Delay(100);
                Progress = i / 100.0;
            }
        }

    }
}
