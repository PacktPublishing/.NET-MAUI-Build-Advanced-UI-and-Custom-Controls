


namespace BindablePropertiesDemo.MyControls;

public partial class ProgressPro : ContentView
{

	//private string title;
	public static readonly BindableProperty TitleProperty =
		BindableProperty.Create("Title", typeof(string), typeof(ProgressPro), "0% To Complete",
			propertyChanged:OnTitlePropertyChanged);

    public static readonly BindableProperty SubTitleProperty =
    BindableProperty.Create("SubTitle", typeof(string), typeof(ProgressPro), "Your progress",
        propertyChanged: OnSubTitlePropertyChanged);

    public static readonly BindableProperty ProgressProperty =
    BindableProperty.Create("Progress", typeof(double), typeof(ProgressPro), 0.0,
    propertyChanged: OnProgressPropertyChanged);

    private static void OnProgressPropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var instance = bindable as ProgressPro;
        if (instance != null)
            instance.ProgressControl.Progress = (double)newValue;
    }

    private static void OnSubTitlePropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var instance = bindable as ProgressPro;
        if (instance != null)
            instance.SubTitleControl.Text = (string)newValue;
    }

    private static void OnTitlePropertyChanged(BindableObject bindable, object oldValue, object newValue)
    {
        var instance = bindable as ProgressPro;
		if(instance != null)
			instance.TitleControl.Text = (string)newValue;
    }

    public string Title
	{
		get { return (string)GetValue(TitleProperty); }
		set { SetValue(TitleProperty, value); }
	}

    public string SubTitle
    {
        get { return (string)GetValue(SubTitleProperty); }
        set { SetValue(SubTitleProperty, value); }
    }

    public string Progress
    {
        get { return (string)GetValue(ProgressProperty); }
        set { SetValue(ProgressProperty, value); }
    }


    public ProgressPro()
	{
		InitializeComponent();
		TitleControl.Text = TitleProperty.DefaultValue.ToString();
	}
}