﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarkupExtensionsDemo
{
    public static class CurrentUser
    {
        public static int UserId { get; set; } = 1;
        public static string UserName { get; set; } = "hp";
        public static string FirstName { get; set; } = "Héctor";
        public static string LastName { get; set; } = "Pérez";
    }

}
