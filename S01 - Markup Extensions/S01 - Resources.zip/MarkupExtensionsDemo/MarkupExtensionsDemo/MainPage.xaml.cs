﻿namespace MarkupExtensionsDemo
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();


            //label.Margin = new Thickness(0, 20, 0, 0);
            //label.Margin = new Thickness(50 / 2);
            //label.Margin = new Thickness(new List<double>
            //{
            //    32,
            //    42,
            //    50,
            //    100
            //}.First());


            //label.FontAttributes = FontAttributes.Bold;

            //label.TextColor = Colors.SteelBlue;
        }

        private void OnCounterClicked(object sender, EventArgs e)
        {
            count++;

            if (count == 1)
                CounterBtn.Text = $"Clicked {count} time";
            else
                CounterBtn.Text = $"Clicked {count} times";

            SemanticScreenReader.Announce(CounterBtn.Text);
        }
    }

}
