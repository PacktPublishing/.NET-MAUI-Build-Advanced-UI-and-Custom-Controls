﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarkupExtensionsDemo.MKExtensions
{
    public class CalculatorExtension : IMarkupExtension<string>
    {

        public int Number1 { get; set; }
        public int Number2 { get; set; }
        public char Operation { get; set; }

        public string ProvideValue(IServiceProvider serviceProvider)
        {
            return Operation switch
            {
                '+' => $"{Number1 + Number2}",
                '-' => $"{Number1 - Number2}",
                '*' => $"{Number1 * Number2}",
                '/' => $"{Number1 / Number2}",
                _ => throw new ArgumentException("Invalid operation"),
            };
        }

        object IMarkupExtension.ProvideValue(IServiceProvider serviceProvider)
        {
            return (this as IMarkupExtension<string>).ProvideValue(serviceProvider);
        }
    }
}
