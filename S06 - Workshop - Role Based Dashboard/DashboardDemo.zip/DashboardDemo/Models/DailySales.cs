﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DashboardDemo.Models
{
    public class DailySales
    {
        public decimal Total { get; set; }
        public DateTime Date { get; set; }
    }
}
