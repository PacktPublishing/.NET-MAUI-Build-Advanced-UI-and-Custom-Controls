﻿using AttachedPropertiesBehaviorsDemo.AttachedProperties;

namespace AttachedPropertiesBehaviorsDemo
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCounterClicked(object sender, EventArgs e)
        {
           //foreach(var item in ParentLayout.Children.OfType<BindableObject>())
           // {
           //     if(ShadowHelper.GetHasShadow(item))
           //     {
           //         //var shadow = new Shadow
           //         //{
           //         //    Radius = 10,
           //         //    Opacity = 0.8f,
           //         //    Brush = Colors.Black,
           //         //    Offset = new Point(5, 5)
           //         //};

           //         //if(item is View viewItem)
           //         //{
           //         //    viewItem.Shadow = shadow;
           //         //}
           //     }
           // }
        }
    }

}
