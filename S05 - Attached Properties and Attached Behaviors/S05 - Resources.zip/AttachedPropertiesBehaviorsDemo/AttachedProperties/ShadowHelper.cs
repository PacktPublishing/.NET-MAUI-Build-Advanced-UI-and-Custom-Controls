﻿using Microsoft.Maui.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttachedPropertiesBehaviorsDemo.AttachedProperties
{
    public class ShadowHelper
    {
        public static readonly BindableProperty HasShadowProperty =
            BindableProperty.CreateAttached("HasShadow", typeof(bool), 
                typeof(ShadowHelper), false, propertyChanged:HasShadowChanged);

        private static void HasShadowChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if(GetHasShadow(bindable))
            {
                var shadow = new Shadow
                {
                    Radius = 10,
                    Opacity = 0.8f,
                    Brush = Colors.Black,
                    Offset = new Point(5, 5)
                };

                if (bindable is View viewItem)
                {
                    viewItem.Shadow = shadow;
                }
            }
            else
            {
                if (bindable is View viewItem)
                {
                    viewItem.Shadow = null;
                }
            }
        }

        public static bool GetHasShadow(BindableObject obj)
        {
            return (bool)obj.GetValue(HasShadowProperty);
        }

        public static void SetHasShadow(BindableObject obj, bool value)
        {
            obj.SetValue(HasShadowProperty, value);
        }

    }
}
